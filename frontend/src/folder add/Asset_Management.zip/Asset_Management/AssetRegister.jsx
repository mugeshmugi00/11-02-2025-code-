import React from "react";

const AssetRegister= () =>{
    return(
        <div>AssetRegister</div>
    )
}
export default AssetRegister;