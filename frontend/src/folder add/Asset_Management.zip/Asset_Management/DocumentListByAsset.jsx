import React from "react";

const DocumentListByAsset= () =>{
    return(
        <div>DocumentListByAsset</div>
    )
}
export default DocumentListByAsset;