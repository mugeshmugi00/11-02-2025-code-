import React from "react";

const AMCNearExpiry= () =>{
    return(
        <div>AMCNearExpiry</div>
    )
}
export default AMCNearExpiry;