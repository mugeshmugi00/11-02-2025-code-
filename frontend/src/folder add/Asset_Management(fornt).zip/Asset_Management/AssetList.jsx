import React from "react";

const AssetList= () =>{
    return(
        <div>AssetList</div>
    )
}
export default AssetList;