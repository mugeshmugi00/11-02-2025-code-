import React from 'react'

const AssetDashboard = () => {
  return (
    <div>AssetDashboard</div>
  )
}

export default AssetDashboard

