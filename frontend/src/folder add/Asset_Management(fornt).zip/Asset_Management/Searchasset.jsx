import React from "react";

const Searchasset= () =>{
    return(
        <div>Searchasset</div>
    )
}
export default Searchasset;